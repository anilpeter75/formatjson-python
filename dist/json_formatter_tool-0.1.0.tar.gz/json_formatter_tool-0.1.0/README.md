# JSON Formatter Tool

A lightweight Python package to format JSON strings with indentation.  

This package is a minimal JSON formatter, and you can also use the free online tool at [Format JSON Online](https://formatjsononline.com).

## Installation
```bash
pip install json-formatter-tool
